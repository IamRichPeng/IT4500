//
//  DateCollectionViewCell.swift
//  Canlendar
//
//  Created by Ruicheng Peng on 11/27/18.
//  Copyright © 2018 Ruicheng Peng. All rights reserved.
//

import UIKit

class DateCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var DateLabel: UILabel!
    
}
